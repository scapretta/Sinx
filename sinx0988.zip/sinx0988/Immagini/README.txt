/*******************************************************

	Sinx for Association V 0.91
	Gestionale per Associazioni senza scopo di lucro
	http://sito.sytes.net
	
********************************************************

SITUAZIONE LEGALE
--------------------------------------------------------
	Rilasciato tramite GNU GPL V3(General Public License).
	Maggiori informazioni http://www.gnu.org/licenses/gpl.txt

	Nessuna garanzia. Nessun supporto. Questa è la beta.

È possibile utilizzare e / o modificare qualsiasi parte del codice.



SPECIFICHE
--------------------------------------------------------

	In questa directory sono persenti immagini del software
	stesso in diversi formati.
	Le immagini si riferiscono alla versione del software 0.91	
	
	La directory di riferimento di questo file è: /Immagini


CONTATTI
--------------------------------------------------------

Per informazioni:
info@sito.sytes.net - http://sito.sytes.net
