/*******************************************************

	Sinx for Association V 0.91
	Gestionale per Associazioni senza scopo di lucro
	http://sito.sytes.net
	
********************************************************

SITUAZIONE LEGALE
--------------------------------------------------------
	Rilasciato tramite GNU GPL V3(General Public License).
	Maggiori informazioni http://www.gnu.org/licenses/gpl.txt

	Nessuna garanzia. Nessun supporto. Questa è la beta.

È possibile utilizzare e / o modificare qualsiasi parte del codice.



SPECIFICHE
--------------------------------------------------------

	Description:
	This is the kde3 icon theme pack for kde4 user.	
	License: GPL (http://www.fsf.org/licenses/gpl.html)
	Depends on  KDE 4.x
	Submitted:  Feb 6 2011
	
	La directory di riferimento di questo file è: /ImmTemplate


CONTATTI
--------------------------------------------------------

Per informazioni:
info@sito.sytes.net - http://sito.sytes.net
